import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'deyoeizv', // ID dari gambar sanity.client.ts kamu
    dataset: 'production'
  }
})